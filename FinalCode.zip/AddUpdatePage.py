from tkinter import *
from tkinter import messagebox
import mysql.connector as ms


def AddFunc(name):
    db = ms.connect(host="localhost", user="root", passwd="urvashi22")

    if db.is_connected():
        print("Connection Established On Add Page")
    else:
        print("Connection Not Connected On Add Page")

    cs = db.cursor()
    cs.execute("use sklh_tv;")

    username = name

    root = Tk()

    root.geometry("1280x720")
    root.title("Add To Profile Page")
    root.configure(bg = "#5E17EB")
    root.resizable(False, False)

    title_var = StringVar()
    status_var = StringVar()

    def submit():
        title = title_var.get()
        status = status_var.get()

        cs.execute("select ID from content where Title = '" + title + "';")
        record = cs.fetchone()

        username = name

        cs.execute("insert into " + username + "content values ('" + record[0] + "','" + status + "');")
        db.commit()

        messagebox.showinfo("Info", "Added " + title.title() + " in " + status.title() + " successfully.")

        title_var.set("")
        status_var.set("")

        root.destroy()
        from YourProfilePage import YourProfilePageFunc
        YourProfilePageFunc(username)

    cs.execute("select distinct ID, Title from content where ID not in (select ID from " + username + "content);")
    records = cs.fetchall()

    record_list = []
    for i in records:
        record_list.append(i[1])
    print(record_list)

    head_label = Label(root, text = "Add To Database", justify = "center", font = ("Gabriola", 30), bg='#C7C7FB')
    head_label.place(x=100, y=80, width=1075, height=75)

    name_label = Label(root, text = "Name : ", font = ("Gabriola", 30), bg='#CCCCFF')
    name_label.place(x=100, y=300, width=300, height=75)

    name_entry = OptionMenu(root, title_var, *record_list)
    name_entry.place(x=425, y=300, width=750, height=75)

    status_label = Label(root, text = "Status : ", font = ("Gabriola", 30), bg='#CCCCFF')
    status_label.place(x=100, y=425, width=300, height=75)

    status_menu = OptionMenu(root, status_var, "Want To Watch", "Watching", "Already Watched")
    status_menu.place(x=425, y=425, width=750, height=75)

    sub_button = Button(root, text = "Submit Entry", font = ("Gabriola", 30), bg='#CBCFEF', command = lambda:submit())
    sub_button.place(x=440, y=600, width=457, height=75)

    def Click():
        root.destroy()
        from YourProfilePage import YourProfilePageFunc
        YourProfilePageFunc(username)

    button_back = Button(root, text="BACK", font = ("Gabriola", 25), bg='#CBCFEF', command = lambda:Click())
    button_back.place(x=5 ,y=5, width=100, height=60)

    root.mainloop()


def UpdateFunc(name):
    db = ms.connect(host="localhost", user="root", passwd="urvashi22")

    if db.is_connected():
        print("Connection Established On Update Page")
    else:
        print("Connection Not Connected On Update Page")

    cs = db.cursor()
    cs.execute("use sklh_tv;")

    username = name

    root = Tk()

    root.geometry("1280x720")
    root.title("Update In Profile Page")
    root.configure(bg = "#5E17EB")
    root.resizable(False, False)

    title_var = StringVar()
    status_var = StringVar()

    def submit():
        title = title_var.get()
        status = status_var.get()

        cs.execute("select ID from content where Title = '" + title + "';")
        record = cs.fetchone()

        username = name

        cs.execute("insert into " + username + "content values ('" + record[0] + "','" + status + "');")
        db.commit()

        messagebox.showinfo("Info", "Updated " + title.title() + " to " + status.title() + " successfully.")

        title_var.set("")
        status_var.set("")

        root.destroy()
        from YourProfilePage import YourProfilePageFunc
        YourProfilePageFunc(username)

    cs.execute("select distinct u.ID, Title from content c, " + username + "content u where c.ID=u.ID;")
    records = cs.fetchall()

    record_list = []
    for i in records:
        record_list.append(i[1])
    print(record_list)

    head_label = Label(root, text = "Update In Database", justify = "center", font = ("Gabriola", 30), bg='#C7C7FB')
    head_label.place(x=100, y=80, width=1075, height=75)

    name_label = Label(root, text = "Name : ", font = ("Gabriola", 30), bg='#CCCCFF')
    name_label.place(x=100, y=300, width=300, height=75)

    name_entry = OptionMenu(root, title_var, *record_list)
    name_entry.place(x=425, y=300, width=750, height=75)

    status_label = Label(root, text = "Status : ", font = ("Gabriola", 30), bg='#CCCCFF')
    status_label.place(x=100, y=425, width=300, height=75)

    status_menu = OptionMenu(root, status_var, "Want To Watch", "Watching", "Already Watched")
    status_menu.place(x=425, y=425, width=750, height=75)

    sub_button = Button(root, text = "Submit Entry", font = ("Gabriola", 30), bg='#CBCFEF', command = lambda:submit())
    sub_button.place(x=440, y=600, width=457, height=75)

    def Click():
        root.destroy()
        from YourProfilePage import YourProfilePageFunc
        YourProfilePageFunc(username)

    button_back = Button(root, text="BACK", font = ("Gabriola", 25), bg='#CBCFEF', command = lambda:Click())
    button_back.place(x=5 ,y=5, width=100, height=60)


    root.mainloop()