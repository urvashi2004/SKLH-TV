from tkinter import *
from  tkinter import ttk
from tkinter.font import Font
from functools import partial
import mysql.connector as ms

def Output(status, name):
    db = ms.connect(host="localhost", user="root", passwd="urvashi22")

    if db.is_connected():
        print("Connection Established On YourContentOutput Page")
    else:
        print("Connection Not Connected On YourContentOutput Page")

    username = name

    cs = db.cursor()

    cs.execute("use sklh_tv;")
    cs.execute("select * from users where Username = '" + username + "';")
    userdata = cs.fetchone()
    print("Userdata is ", userdata)

    cs.execute("select c.ID, Title, Type, Year, Country, Genre, Summary from content c," + username + "content u where c.ID = u.ID and Status = '" + status +"';")

    data = cs.fetchall()
    print(data)

    root  = Tk()

    root.geometry("1280x720")
    root.title("Your Profile Page")
    root.configure(bg = "#5E17EB")
    root.resizable(False, False)

    type_label = Label(root, text = userdata[1] + "'s " + status + " List", font = ("Gabriola", 30), bg='#C7C7FB')
    type_label.place(x=125, y=40, width=1025, height=75)

    frame = Frame(root)
    frame.pack()
    frame.place(x=125, y=150, width=1025, height=523)

    #scrollbar
    scrolly = Scrollbar(frame)
    scrolly.pack(side=RIGHT, fill=Y)

    style = ttk.Style()

    style.theme_use("clam")

    style.configure("Treeview",
        foreground='black',
        fieldbackground='#E6E6FA',
        rowheight=70)

    style.map('Treeview',
        background=[('selected','#5E17EB')])

    table1 = ttk.Treeview(frame, yscrollcommand=scrolly.set, height=7, selectmode = 'browse')
    table1.place(x=125, y=150, width=1060, height=520)
    table1.pack()

    scrolly.config(command=table1.yview)

    #define our column
    table1['columns'] = ('col_id', 'col_name', 'col_type', 'col_year', 'col_region','col_genre','col_summary')

    # format our column
    table1.column("#0", width=0, stretch=False)
    table1.column("col_id",anchor=CENTER, width=50)
    table1.column("col_name",anchor=CENTER,width=160)
    table1.column("col_type",anchor=CENTER,width=60)
    table1.column("col_year",anchor=CENTER,width=50)
    table1.column("col_region",anchor=CENTER,width=100)
    table1.column("col_genre",anchor=CENTER,width=100)
    table1.column("col_summary",anchor=CENTER,width=485)

    #Create Headings 
    table1.heading("#0",text="",anchor=CENTER)
    table1.heading("col_id",text="ID",anchor=CENTER)
    table1.heading("col_name",text="NAME",anchor=CENTER)
    table1.heading("col_type",text="TYPE",anchor=CENTER)
    table1.heading("col_year",text="YEAR",anchor=CENTER)
    table1.heading("col_region",text="REGION",anchor=CENTER)
    table1.heading("col_genre",text="GENRE",anchor=CENTER)
    table1.heading("col_summary",text="SUMMARY",anchor=CENTER)

    #add data
    cs.execute("select c.ID, Title, Type, Year, Country, Genre, Summary from content c," + username + "content u where c.ID = u.ID and Status = '" + status + "';")

    global k
    k = 0
    for i in range(1,len(data)+1):
        if k%2==0:
            dat = cs.fetchone()
            table1.insert(parent='', index='end', iid=i, text='', values=dat, tag=('odd',))
        else:
            dat = cs.fetchone()
            table1.insert(parent='', index='end', iid=i, text='', values=dat, tag=('even',))
        k += 1

    table1.tag_configure('odd', background='#CCCCFF')
    table1.tag_configure('even', background='#E6E6FA')

    table1.pack()

    def motion_handler(tree, event):
        f = Font(font='TkDefaultFont')
        # A helper function that will wrap a given value based on column width
        def adjust_newlines(val, width, pad=10):
            if not isinstance(val, str):
                return val
            else:
                words = val.split()
                lines = [[],]
                for word in words:
                    line = lines[-1] + [word,]
                    if f.measure(' '.join(line)) < (width - pad):
                        lines[-1].append(word)
                    else:
                        lines[-1] = ' '.join(lines[-1])
                        lines.append([word,])

                if isinstance(lines[-1], list):
                    lines[-1] = ' '.join(lines[-1])

                return '\n'.join(lines)

        if (event is None) or (tree.identify_region(event.x, event.y) == "separator"):
            # You may be able to use this to only adjust the two columns that you care about
            # print(tree.identify_column(event.x))

            col_widths = [tree.column(cid)['width'] for cid in tree['columns']]

            for iid in tree.get_children():
                new_vals = []
                for (v,w) in zip(tree.item(iid)['values'], col_widths):
                    new_vals.append(adjust_newlines(v, w))
                tree.item(iid, values=new_vals)

    table1.bind('<B1-Motion>', partial(motion_handler, table1))
    motion_handler(table1, None)   # Perform initial wrapping

    table1.pack()

    username = name

    def Click():
        root.destroy()
        from YourProfilePage import YourProfilePageFunc
        YourProfilePageFunc(username)

    button_back = Button(root, text="BACK", font = ("Gabriola", 25), bg='#CBCFEF', comman=lambda:Click())
    button_back.place(x=5 ,y=5, width=100, height=60)

    root.mainloop()