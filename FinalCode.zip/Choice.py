from tkinter import *

def ChoiceFunc():
    root = Tk()

    root.geometry("1280x720")
    root.title("Choice Page")
    root.configure(bg = "#5E17EB")
    root.resizable(False, False)

    def ClickReg():
        root.destroy()
        from Register import RegisterFunc
        RegisterFunc()

    def ClickLog():
        root.destroy()
        from Login import LoginFunc
        LoginFunc()

    type_label = Label(root, text = "Select An Option To Enter", font = ("Gabriola", 35), bg='#C7C7FB')
    type_label.place(x=210, y=80, width=840, height=75)

    register_but = Button(root, text = "Register", font = ("Gabriola", 35), bg='#CCCCFF', command = lambda:ClickReg())
    register_but.place(x=210, y=220, width=400, height=400)

    log_but = Button(root, text = "Login", font = ("Gabriola", 35), bg='#CCCCFF', command = lambda:ClickLog())
    log_but.place(x=650, y=220, width=400, height=400)

    button_quit = Button(root, text="QUIT", font = ("Gabriola", 30), bg='#CBCFEF', command=lambda:root.destroy())
    button_quit.place(x=5 ,y=5, width=100, height=60)

    root.mainloop()