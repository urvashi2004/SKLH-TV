from tkinter import *
from YourContentPage import *

def YourProfilePageFunc(name):
    root = Tk()

    root.geometry("1280x720")
    root.title("Your Profile Page")
    root.configure(bg = "#5E17EB")
    root.resizable(False, False)

    username = name

    db = ms.connect(host="localhost", user="root", passwd="urvashi22")

    if db.is_connected():
        print("Connection Established On Explore Genre Page")
    else:
        print("Connection Not Connected On Explore Genre Page")

    cs = db.cursor()
    
    cs.execute("use sklh_tv;")
    cs.execute("select * from users where Username = '" + username + "';")
    userdata = cs.fetchone()
    print("Userdata is ", userdata)

    type_label = Label(root, text = userdata[1] + "'s Profile", font = ("Gabriola", 30), bg='#C7C7FB')
    type_label.place(x=90, y=80, width=1090, height=75)

    status = ["Want To Watch", "Watching", "Watched"]

    def Want_Click():
        root.destroy()
        Output(status[0], username)

    want_but = Button(root, text = "Want To Watch", font = ("Gabriola", 30), bg='#CCCCFF', command=lambda:Want_Click())
    want_but.place(x=90, y=220, width=320, height=320)

    def Watched_Click():
        root.destroy()
        Output(status[2], username)

    done_but = Button(root, text = "Already Watched", font = ("Gabriola", 30), bg='#CCCCFF', command=lambda:Watched_Click())
    done_but.place(x=475, y=220, width=320, height=320)
    
    def Watching_Click():
        root.destroy()
        Output(status[1], username)

    watch_but = Button(root, text = "Watching", font = ("Gabriola", 30), bg='#CCCCFF', command=lambda:Watching_Click())
    watch_but.place(x=860, y=220, width=320, height=320)

    username = name

    def ClickAdd(name):
        root.destroy()
        from AddUpdatePage import AddFunc
        AddFunc(name)

    add_but  = Button(root, text='Add', font= ("Gabriola", 25), bg='#CBCFEF', command=lambda:ClickAdd(username))
    add_but.place(x=250, y=620, width=370, height=60)

    def ClickUpdate(name):
        root.destroy()
        from AddUpdatePage import UpdateFunc
        UpdateFunc(name)

    update_but = Button(root, text='Update', font= ("Gabriola", 25), bg='#CBCFEF', command=lambda:ClickUpdate(username))
    update_but.place(x=670, y=620, width=370, height=60)

    def Click():
        root.destroy()
        from HomePageChoices import HomePageChoicesFunc
        HomePageChoicesFunc(username)

    button_back = Button(root, text="BACK", font = ("Gabriola", 25), bg='#CBCFEF', command=lambda:Click())
    button_back.place(x=5 ,y=5, width=100, height=60)

    root.mainloop()