from tkinter import *
from tkinter import messagebox
from GenrePage import *
from Login import *
from Recommendation import *
from Register import *
from RequestPage import *
from YourProfilePage import *

def HomePageChoicesFunc(root, name):
    root.title("Home Page")

    username = name

    db = ms.connect(host="localhost", user="root", passwd="urvashi22")

    if db.is_connected():
        print("Connection Established On Explore Genre Page")
    else:
        print("Connection Not Connected On Explore Genre Page")

    cs = db.cursor()
    
    cs.execute("use sklh_tv;")
    cs.execute("select * from users where Username = '" + username + "';")
    userdata = cs.fetchone()
    print("Userdata is ", userdata)

    label_heading = Label(root, text = "Welcome " + userdata[1], justify = "center", font = ("Gabriola", 30), bg='#C7C7FB')
    label_heading.place(x=150, y=40, width=960, height=75)

    def ClickExp():
        Destroy()
        GenreFunc(root, username)

    explore_but = Button(root, text = "Explore", font = ("Gabriola", 30), bg='#CCCCFF', command=lambda:ClickExp())
    explore_but.place(x=150, y=170, width=450, height=200)

    def ClickYour():
        Destroy()
        YourProfilePageFunc(root, username)

    your_but = Button(root, text = "Your Content", font = ("Gabriola", 30), bg='#CCCCFF', command=lambda:ClickYour())
    your_but.place(x=665, y=170, width=450, height=200)

    def ClickRecs():
        Destroy()
        RecommenFunc(root, username)

    recs_but = Button(root, text = "Reccomendations", font = ("Gabriola", 30), bg='#CCCCFF', command=lambda:ClickRecs())
    recs_but.place(x=150, y=435, width=450, height=200)

    def ClickReq():
        Destroy()
        RequestPageFunc(root, username)

    req_but = Button(root, text = "Request To Add", font = ("Gabriola", 30), bg='#CCCCFF', command=lambda:ClickReq())
    req_but.place(x=665, y=435, width=450, height=200)

    def Click():
        Destroy()
        from Choice import ChoiceFunc
        ChoiceFunc(root)

    logout = Button(root, text="Logout", font = ("Gabriola", 25), bg='#CBCFEF', command=lambda:Click())
    logout.place(x=5 ,y=5, width=120, height=60)

    def Del_Click():
        cs.execute("delete from users where username='" + username + "';")
        cs.execute("drop table " + username + "content;")
        db.commit()
        messagebox.showinfo("Account Deleted", "Account having username " + username + " deleted successfully.")
        Destroy()
        from Choice import ChoiceFunc
        ChoiceFunc(root)
    
    del_button = Button(root, text="Delete Account", font = ("Gabriola", 25), bg='#CBCFEF', command=lambda:Del_Click())
    del_button.place(x=465, y=650, width=300, height=65)

    def Destroy():
        label_heading.destroy()
        explore_but.destroy()
        your_but.destroy()
        recs_but.destroy()
        req_but.destroy()
        del_button.destroy()
        logout.destroy()