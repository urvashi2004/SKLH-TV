from tkinter import *

#create a tkinter window
root = Tk()

#design the window created
root.geometry("1280x720")
root.title("Logo Page")
root.resizable(False, False)
root.config(bg = "#5E17EB")

#insert an image
photo = PhotoImage(file = "SKLH TV Logo.png")
photoimage = photo.subsample(1)

def Click():
    Logo_But.destroy()  #to remove the previous label
    from Choice import ChoiceFunc
    ChoiceFunc(root)

Logo_But = Button(root, image = photoimage, command = lambda:Click())
Logo_But.place(x=350, y=65, height=600, width=600)

root.mainloop()