from tkinter import *
from YourContentPage import *

def YourProfilePageFunc(root, name):

    root.title("Your Profile Page")

    username = name

    db = ms.connect(host="localhost", user="root", passwd="urvashi22")

    if db.is_connected():
        print("Connection Established On Explore Genre Page")
    else:
        print("Connection Not Connected On Explore Genre Page")

    cs = db.cursor()
    
    cs.execute("use sklh_tv;")
    cs.execute("select * from users where Username = '" + username + "';")
    userdata = cs.fetchone()
    print("Userdata is ", userdata)

    type_label = Label(root, text = userdata[1] + "'s Profile", font = ("Gabriola", 30), bg='#C7C7FB')
    type_label.place(x=90, y=80, width=1090, height=75)

    #status = ["Want To Watch", "Watching", "Watched"]

    def Content_Click():
        Destroy()
        Output(root, username)

    content_but = Button(root, text = "Content", font = ("Gabriola", 30), bg='#CCCCFF', command=lambda:Content_Click())
    content_but.place(x=90, y=220, width=1090, height=320)

    username = name

    def ClickAdd(name):
        Destroy()
        from AddUpdateDelPage import AddFunc
        AddFunc(root, name)

    add_but  = Button(root, text='Add', font= ("Gabriola", 25), bg='#CBCFEF', command=lambda:ClickAdd(username))
    add_but.place(x=90, y=620, width=320, height=60)

    def ClickUpdate(name):
        Destroy()
        from AddUpdateDelPage import UpdateFunc
        UpdateFunc(root, name)

    update_but = Button(root, text='Update', font= ("Gabriola", 25), bg='#CBCFEF', command=lambda:ClickUpdate(username))
    update_but.place(x=475, y=620, width=330, height=60)

    def ClickDelete(name):
        Destroy()
        from AddUpdateDelPage import DeleteFunc
        DeleteFunc(root, name)

    delete_but = Button(root, text='Delete', font= ("Gabriola", 25), bg='#CBCFEF', command=lambda:ClickDelete(username))
    delete_but.place(x=860, y=620, width=330, height=60)

    def Click():
        Destroy()
        from HomePageChoices import HomePageChoicesFunc
        HomePageChoicesFunc(root, username)

    button_back = Button(root, text="Back", font = ("Gabriola", 25), bg='#CBCFEF', command=lambda:Click())
    button_back.place(x=5 ,y=5, width=100, height=60)

    def Destroy():
        type_label.destroy()
        content_but.destroy()
        add_but.destroy()
        update_but.destroy()
        delete_but.destroy()
        button_back.destroy()