from tkinter import *
from GenrePageOutput import *

def GenreFunc(root, name):
    root.title("Genre Page")
    username = name

    label_heading = Label(root, text = "SELECT GENRE", justify = "center", font = ("Gabriola", 30), bg = '#C7C7FB')
    label_heading.place(x = 110, y = 60, width = 1030, height = 75)

    list = ["Action", "Comedy", "Thriller", "Drama", "Fantasy", "Romance"]

    def Output(genre):
        Destroy()
        GenrePageOutputFunc(root, genre, username)

    button_1 = Button(root, text = "Action", font = ("Gabriola", 30), bg = '#CCCCFF', command = lambda:Output(list[0]))
    button_1.place(x = 110, y = 200, width = 300, height = 180)

    button_2 = Button(root, text = "Comedy", font = ("Gabriola", 30), bg = '#CCCCFF', command = lambda:Output(list[1]))
    button_2.place(x = 475, y = 200, width = 300, height = 180)

    button_3 = Button(root, text = "Thriller", font = ("Gabriola", 30), bg = '#CCCCFF', command = lambda:Output(list[2]))
    button_3.place(x = 840, y = 200, width = 300, height = 180)

    button_4 = Button(root, text = "Drama", font = ("Gabriola", 30), bg = '#CCCCFF', command = lambda:Output(list[3]))
    button_4.place(x = 110, y = 445, width = 300, height = 180)

    button_5 = Button(root, text = "Fantasy", font = ("Gabriola", 30), bg = '#CCCCFF', command = lambda:Output(list[4]))
    button_5.place(x = 475, y = 445, width = 300, height = 180)

    button_6 = Button(root, text = "Romance", font = ("Gabriola", 30), bg = '#CCCCFF', command = lambda:Output(list[5]))
    button_6.place(x = 840, y = 445, width = 300, height = 180)

    def Click():
        Destroy()
        from HomePageChoices import HomePageChoicesFunc
        HomePageChoicesFunc(root, username)

    button_back = Button(root, text = "Back", font = ("Gabriola", 25), bg = '#CBCFEF', command = lambda:Click())
    button_back.place(x = 5 ,y = 5, width = 100, height = 60)

    def Destroy():
        label_heading.destroy()
        button_1.destroy()
        button_2.destroy()
        button_3.destroy()
        button_4.destroy()
        button_5.destroy()
        button_6.destroy()
        button_back.destroy()