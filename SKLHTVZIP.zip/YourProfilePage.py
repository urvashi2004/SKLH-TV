from tkinter import * 
from YourContentPage import *

def YourProfilePageFunc():
    root = Tk()

    root.geometry("1280x720")
    root.title("Your Profile Page")
    root.configure(bg = "#5E17EB")
    root.resizable(False, False)

    type_label = Label(root, text = "Your Profile", font = ("Arial", 25))
    type_label.place(x=125, y=40, width=1025, height=75)

    def Want_Click():
        root.destroy
        WantToWatch()

    want_but = Button(root, text = "Want To Watch", font = ("Arial", 25), command=lambda:Want_Click())
    want_but.place(x=100, y=220, width=500, height=200)

    def Watching_Click():
        root.destroy
        Watching()

    watch_but = Button(root, text = "Watching", font = ("Arial", 25), command=lambda:Watching_Click())
    watch_but.place(x=700, y=220, width=500, height=200)

    def Watched_Click():
        root.destroy
        Watched()

    done_but = Button(root, text = "Already Watched", font = ("Arial", 25), command=lambda:Watched_Click())
    done_but.place(x=400, y=480, width=500, height=200)

    def Click():
        root.destroy()
        from HomePageChoices import HomePageChoicesFunc
        HomePageChoicesFunc()

    button_back = Button(root, text="BACK", font = ("Arial", 20), borderwidth=0, command=lambda:Click())
    button_back.place(x=5 ,y=5, width=100, height=60)

    root.mainloop()