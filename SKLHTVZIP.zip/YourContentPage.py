from tkinter import *
from  tkinter import ttk
import mysql.connector as ms

def WantToWatch():
    db = ms.connect(host="localhost", user="root", passwd="urvashi22")

    if db.is_connected():
        print("Connection Established On YourContentOutput Page")
    else:
        print("Connection Not Connected On YourContentOutput Page")

    cs = db.cursor()

    cs.execute("use sklh_tv;")
    cs.execute("select * from content," + saveuser + "content where content.ID = " + saveuser + "content ID and Status = 'Want To Watch;")

    data = cs.fetchall()

    root  = Tk()

    root.geometry("1280x720")
    root.title("Your Profile Page")
    root.configure(bg = "#5E17EB")
    root.resizable(False, False)

    type_label = Label(root, text = "Your Want To Watch List", font = ("Arial", 25))
    type_label.place(x=125, y=40, width=1025, height=75)

    game_frame = Frame(root)
    game_frame.pack()
    game_frame.place(x=125, y=150, width=1025, height=500)

    #scrollbar
    game_scrolly = Scrollbar(game_frame)
    game_scrolly.pack(side=RIGHT, fill=Y)

    game_scroll = Scrollbar(game_frame, orient='horizontal')
    game_scroll.pack(side= BOTTOM, fill=X)

    table1 = ttk.Treeview(game_frame, yscrollcommand=game_scrolly.set, xscrollcommand = game_scroll.set)
    table1.place(x=125, y=150, width=1060, height=500)
    table1.pack()

    game_scroll.config(command=table1.xview)
    game_scrolly.config(command=table1.yview)

    #define our column
    table1['columns'] = ('col_id', 'col_name', 'col_type', 'col_year', 'col_region','col_genre','col_summary')

    # format our column
    table1.column("#0", width=0, stretch=False)
    table1.column("col_id",anchor=CENTER, width=50)
    table1.column("col_name",anchor=CENTER,width=160)
    table1.column("col_type",anchor=CENTER,width=60)
    table1.column("col_year",anchor=CENTER,width=50)
    table1.column("col_region",anchor=CENTER,width=100)
    table1.column("col_genre",anchor=CENTER,width=100)
    table1.column("col_summary",anchor=CENTER,width=485)

    #Create Headings 
    table1.heading("#0",text="",anchor=CENTER)
    table1.heading("col_id",text="ID",anchor=CENTER)
    table1.heading("col_name",text="NAME",anchor=CENTER)
    table1.heading("col_type",text="TYPE",anchor=CENTER)
    table1.heading("col_year",text="YEAR",anchor=CENTER)
    table1.heading("col_region",text="REGION",anchor=CENTER)
    table1.heading("col_genre",text="GENRE",anchor=CENTER)
    table1.heading("col_summary",text="SUMMARY",anchor=CENTER)

    #add data
    cs.execute("select * from content," + saveuser + "content where content.ID = " + saveuser + "content ID and Status = 'Want To Watch';")
    for i in range(1,len(data)+1):
        dat = cs.fetchone()
        table1.insert(parent='',index='end',iid=i,text='',values=dat)

    table1.pack()

    button_back = Button(root, text="BACK", font = ("Arial", 20), borderwidth=0)
    button_back.place(x=5 ,y=5, width=100, height=60)

    root.mainloop()

def Watching():
    db = ms.connect(host="localhost", user="root", passwd="urvashi22")

    if db.is_connected():
        print("Connection Established On YourContentOutput Page")
    else:
        print("Connection Not Connected On YourContentOutput Page")

    cs = db.cursor()

    cs.execute("use sklh_tv;")
    cs.execute("select * from content," + saveuser + "content where content.ID = " + saveuser + "content ID and Status = 'Watching';")

    data = cs.fetchall()

    root  = Tk()

    root.geometry("1280x720")
    root.title("Your Profile Page")
    root.configure(bg = "#5E17EB")
    root.resizable(False, False)

    type_label = Label(root, text = "Your Want To Watch List", font = ("Arial", 25))
    type_label.place(x=125, y=40, width=1025, height=75)

    game_frame = Frame(root)
    game_frame.pack()
    game_frame.place(x=125, y=150, width=1025, height=500)

    #scrollbar
    game_scrolly = Scrollbar(game_frame)
    game_scrolly.pack(side=RIGHT, fill=Y)

    game_scroll = Scrollbar(game_frame, orient='horizontal')
    game_scroll.pack(side= BOTTOM, fill=X)

    table1 = ttk.Treeview(game_frame, yscrollcommand=game_scrolly.set, xscrollcommand = game_scroll.set)
    table1.place(x=125, y=150, width=1060, height=500)
    table1.pack()

    game_scroll.config(command=table1.xview)
    game_scrolly.config(command=table1.yview)

    #define our column
    table1['columns'] = ('col_id', 'col_name', 'col_type', 'col_year', 'col_region','col_genre','col_summary')

    # format our column
    table1.column("#0", width=0, stretch=False)
    table1.column("col_id",anchor=CENTER, width=50)
    table1.column("col_name",anchor=CENTER,width=160)
    table1.column("col_type",anchor=CENTER,width=60)
    table1.column("col_year",anchor=CENTER,width=50)
    table1.column("col_region",anchor=CENTER,width=100)
    table1.column("col_genre",anchor=CENTER,width=100)
    table1.column("col_summary",anchor=CENTER,width=485)

    #Create Headings 
    table1.heading("#0",text="",anchor=CENTER)
    table1.heading("col_id",text="ID",anchor=CENTER)
    table1.heading("col_name",text="NAME",anchor=CENTER)
    table1.heading("col_type",text="TYPE",anchor=CENTER)
    table1.heading("col_year",text="YEAR",anchor=CENTER)
    table1.heading("col_region",text="REGION",anchor=CENTER)
    table1.heading("col_genre",text="GENRE",anchor=CENTER)
    table1.heading("col_summary",text="SUMMARY",anchor=CENTER)

    #add data
    cs.execute("select * from content," + saveuser + "content where content.ID = " + saveuser + "content ID and Status = 'Watching';")
    for i in range(1,len(data)+1):
        dat = cs.fetchone()
        table1.insert(parent='',index='end',iid=i,text='',values=dat)

    table1.pack()

    button_back = Button(root, text="BACK", font = ("Arial", 20), borderwidth=0)
    button_back.place(x=5 ,y=5, width=100, height=60)

    root.mainloop()

def Watched():
    db = ms.connect(host="localhost", user="root", passwd="urvashi22")

    if db.is_connected():
        print("Connection Established On YourContentOutput Page")
    else:
        print("Connection Not Connected On YourContentOutput Page")

    cs = db.cursor()

    cs.execute("use sklh_tv;")
    cs.execute("select * from content," + saveuser + "content where content.ID = " + saveuser + "content ID and Status = 'Watched';")

    data = cs.fetchall()

    root  = Tk()

    root.geometry("1280x720")
    root.title("Your Profile Page")
    root.configure(bg = "#5E17EB")
    root.resizable(False, False)

    type_label = Label(root, text = "Your Want To Watch List", font = ("Arial", 25))
    type_label.place(x=125, y=40, width=1025, height=75)

    game_frame = Frame(root)
    game_frame.pack()
    game_frame.place(x=125, y=150, width=1025, height=500)

    #scrollbar
    game_scrolly = Scrollbar(game_frame)
    game_scrolly.pack(side=RIGHT, fill=Y)

    game_scroll = Scrollbar(game_frame, orient='horizontal')
    game_scroll.pack(side= BOTTOM, fill=X)

    table1 = ttk.Treeview(game_frame, yscrollcommand=game_scrolly.set, xscrollcommand = game_scroll.set)
    table1.place(x=125, y=150, width=1060, height=500)
    table1.pack()

    game_scroll.config(command=table1.xview)
    game_scrolly.config(command=table1.yview)

    #define our column
    table1['columns'] = ('col_id', 'col_name', 'col_type', 'col_year', 'col_region','col_genre','col_summary')

    # format our column
    table1.column("#0", width=0, stretch=False)
    table1.column("col_id",anchor=CENTER, width=50)
    table1.column("col_name",anchor=CENTER,width=160)
    table1.column("col_type",anchor=CENTER,width=60)
    table1.column("col_year",anchor=CENTER,width=50)
    table1.column("col_region",anchor=CENTER,width=100)
    table1.column("col_genre",anchor=CENTER,width=100)
    table1.column("col_summary",anchor=CENTER,width=485)

    #Create Headings 
    table1.heading("#0",text="",anchor=CENTER)
    table1.heading("col_id",text="ID",anchor=CENTER)
    table1.heading("col_name",text="NAME",anchor=CENTER)
    table1.heading("col_type",text="TYPE",anchor=CENTER)
    table1.heading("col_year",text="YEAR",anchor=CENTER)
    table1.heading("col_region",text="REGION",anchor=CENTER)
    table1.heading("col_genre",text="GENRE",anchor=CENTER)
    table1.heading("col_summary",text="SUMMARY",anchor=CENTER)

    #add data
    cs.execute("select * from content," + saveuser + "content where content.ID = " + saveuser + "content ID and Status = 'Watched';")
    for i in range(1,len(data)+1):
        dat = cs.fetchone()
        table1.insert(parent='',index='end',iid=i,text='',values=dat)

    table1.pack()

    button_back = Button(root, text="BACK", font = ("Arial", 20), borderwidth=0)
    button_back.place(x=5 ,y=5, width=100, height=60)

    root.mainloop()