#for scroll bar in a table
'''from tkinter import *
from  tkinter import ttk


root  = Tk()
root.title('PythonGuides')
root.geometry('500x500')
root['bg'] = '#AC99F2'

game_frame = Frame(root)
game_frame.pack()

#scrollbar
game_scroll_y = Scrollbar(game_frame)
game_scroll_y.pack(side=RIGHT, fill=Y)

game_scroll = Scrollbar(game_frame,orient='horizontal')
game_scroll.pack(side= BOTTOM,fill=X)

my_game = ttk.Treeview(game_frame, xscrollcommand=game_scroll.set, yscrollcommand =game_scroll_y.set)

my_game.pack()

game_scroll_y.config(command=my_game.yview)
game_scroll.config(command=my_game.xview)

#define our column
 
my_game['columns'] = ('player_id', 'player_name', 'player_Rank', 'player_states', 'player_city')

# format our column
my_game.column("#0", width=0,  stretch=NO)
my_game.column("player_id",anchor=CENTER, width=80)
my_game.column("player_name",anchor=CENTER,width=80)
my_game.column("player_Rank",anchor=CENTER,width=80)
my_game.column("player_states",anchor=CENTER,width=80)
my_game.column("player_city",anchor=CENTER,width=80)

#Create Headings 
my_game.heading("#0",text="",anchor=CENTER)
my_game.heading("player_id",text="Id",anchor=CENTER)
my_game.heading("player_name",text="Name",anchor=CENTER)
my_game.heading("player_Rank",text="Rank",anchor=CENTER)
my_game.heading("player_states",text="States",anchor=CENTER)
my_game.heading("player_city",text="States",anchor=CENTER)

#add data 
my_game.insert(parent='',index='end',iid=0,text='',
values=('1','Ninja','101','Oklahoma', 'Moore'))
my_game.insert(parent='',index='end',iid=1,text='',
values=('2','Ranger','102','Wisconsin', 'Green Bay'))
my_game.insert(parent='',index='end',iid=2,text='',
values=('3','Deamon','103', 'California', 'Placentia'))
my_game.insert(parent='',index='end',iid=3,text='',
values=('4','Dragon','104','New York' , 'White Plains'))
my_game.insert(parent='',index='end',iid=4,text='',
values=('5','CrissCross','105','California', 'San Diego'))
my_game.insert(parent='',index='end',iid=5,text='',
values=('6','ZaqueriBlack','106','Wisconsin' , 'TONY'))
my_game.insert(parent='',index='end',iid=6,text='',
values=('7','RayRizzo','107','Colorado' , 'Denver'))
my_game.insert(parent='',index='end',iid=7,text='',
values=('8','Byun','108','Pennsylvania' , 'ORVISTON'))
my_game.insert(parent='',index='end',iid=8,text='',
values=('9','Trink','109','Ohio' , 'Cleveland'))
my_game.insert(parent='',index='end',iid=9,text='',
values=('10','Twitch','110','Georgia' , 'Duluth'))
my_game.insert(parent='',index='end',iid=10,text='',
values=('11','Animus','111', 'Connecticut' , 'Hartford'))
my_game.pack()

root.mainloop()'''



#for messageboxes
'''from tkinter import * 
from tkinter import messagebox
  
root = Tk()
root.geometry("300x200")
  
w = Label(root, text ='GeeksForGeeks', font = "50") 
w.pack()
  
messagebox.showinfo("showinfo", "Information")
  
messagebox.showwarning("showwarning", "Warning")
  
messagebox.showerror("showerror", "Error")
  
messagebox.askquestion("askquestion", "Are you sure?")
  
messagebox.askokcancel("askokcancel", "Want to continue?")
  
messagebox.askyesno("askyesno", "Find the value?")
  
  
messagebox.askretrycancel("askretrycancel", "Try again?")  
  
root.mainloop() '''



#something new
import mysql.connector as ms
from tkinter import *

root = Tk()

db = ms.connect(host="localhost",user="root",passwd="urvashi22")

if db.is_connected():
    print("Connection Established")
else:
    print("Connection Not Connected")

cs = db.cursor()

cs.execute("use sklh_tv;")
cs.execute("select * from content;")
data = cs.fetchall()

root.geometry("1280x720")
root.title("Explore Page")
root.configure(bg = "#5E17EB")
root.resizable(False, False)

counter = -1

def button(name):

    def Click():
        root.destroy()
        from AddToProfilePage import AddToProfilePageFunc
        AddToProfilePageFunc()

    name = Button(root, text = name, font = ("Arial", 25), command = lambda:Click())
    name.place(x=xp, y=yp, width=350, height=50)

for xp in range(100,1100,370):
    for yp in range(100,650,70):
        for i in range(len(data)):
            print(i)
            while counter < 39:
                counter += 1
                print("Count",counter)
                button(data[counter][1])
                print("Counter is",counter)

root.mainloop()