

from tkinter import *
from tkinter import messagebox
from tkinter import ttk
import importlib

from login import studentlogin
studentlogin()
quit
