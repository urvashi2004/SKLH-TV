-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: localhost    Database: mydata
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `electronic`
--

DROP TABLE IF EXISTS `electronic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `electronic` (
  `Store` varchar(45) DEFAULT NULL,
  `Category` varchar(45) DEFAULT NULL,
  `Year` varchar(45) DEFAULT NULL,
  `Place` varchar(45) DEFAULT NULL,
  `Product_id` int NOT NULL,
  `Product_name` varchar(45) DEFAULT NULL,
  `Company name` varchar(45) DEFAULT NULL,
  `Model no` varchar(45) DEFAULT NULL,
  `Rating` varchar(45) DEFAULT NULL,
  `Price` int DEFAULT NULL,
  `Quantity` int DEFAULT NULL,
  `M.R.P` int DEFAULT NULL,
  `Phone` int DEFAULT NULL,
  `Warranty` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`Product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `electronic`
--

LOCK TABLES `electronic` WRITE;
/*!40000 ALTER TABLE `electronic` DISABLE KEYS */;
INSERT INTO `electronic` VALUES ('Croma','T.V','2019','Delhi',1,'Bravia','Sony','KD-65X9300E','5',179999,15,224900,22003344,'1-Year'),('Croma','Smartphone','2020','Gurugram',2,'S22-Ultra','Samsung','SM-S908EZKGINU','5',109999,20,109999,22885566,'1-Year'),('Croma','A.C','2021','Ghaziabad',3,'1.5 ton split AC','LG','PS-Q19BWZF','5',50590,18,77990,44553388,'1-Year'),('Croma','Laptops','2022','Vaishali',4,'Book laptop','Realme','RMNB1001','4',42999,16,46999,55336677,'1-Year'),('Reliance Digital','T.V','2019','Delhi',5,'Crystal 4K UHD','Samsung','AU80000','5',184990,25,254900,22886655,'1-Year'),('Reliance Digital','Smartphone','2020','Gurugram',6,'X7 pro','Realme','RMX2121','5',29999,24,32999,44552299,'1-Year'),('Reliance Digital','A.C','2021','Ghaziabad',7,'WindFree split AC','Samsung','AR18BY4ARWK','4',43490,28,66990,66442277,'1-Year'),('Reliance Digital','Laptops','2022','Vaishali',8,'Notebook Ultra','Redmi','A145BZ-32D','3',58999,25,71999,22775566,'1-Year'),('Sargam','T.V','2019','Delhi',9,'Smart TV 104cm','Realme','43D56FG','4',25999,45,26999,22775599,'1-Year'),('Sargam','Smartphone','2020','Gurugram',10,'9A Sport','Redmi','43Gh67UT','3',6999,10,8499,22008844,'1-Year'),('Sargam','A.C','2021','Ghaziabad',11,'1.5 Ton AI Dual','LG','Q19FNZF','2',45500,5,76990,22003399,'1-Year'),('Sargam','Laptops','2022','Vaishali',12,'VAIO','Sony','VJS131X0211B','1',125693,2,150832,22774499,'1-Year'),('Vijay Sales','T.V','2019','Delhi',13,'Crystal 8K','Samsung','AU8000','4',419990,40,629900,22774499,'1-Year'),('Vijay Sales','Smartphone','2020','Gurugram',14,'Xperia PRO-1','Sony','4GH78KH','4',137237,9,150000,22774466,'1-Year'),('Vijay Sales','A.C','2021','Ghaziabad',15,'Split AC','Samsung','AR12AYMYATBNNA','1',29400,6,35999,44557722,'1-Year'),('Vijay Sales','Laptops','2022','Vaishali',16,'Galaxy Book Go','Samsung','4D6G23F','3',38990,16,47990,99447722,'1-Year');
/*!40000 ALTER TABLE `electronic` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-03-27 12:03:03
