from tkinter import*
from tkinter import ttk 
from PIL import Image,ImageTk    #pip install pillow
import mysql.connector
from tkinter import messagebox
from tkinter import filedialog
import os


class Electronic:
    def __init__(self,root):
        self.root=root
        self.root.geometry("1530x790+0+0")
        self.root.title("ELECTRONIC SHOP MANAGEMENT")


        #variable
        self.var_store=StringVar()
        self.var_category=StringVar()
        self.var_year=StringVar()
        self.var_place=StringVar()
        self.var_id=StringVar()
        self.var_name=StringVar()
        self.var_company=StringVar()
        self.var_model=StringVar()  
        self.var_rating=StringVar()
        self.var_price=StringVar()
        self.var_quantity=StringVar()
        self.var_mrp=StringVar()
        self.var_phone=StringVar()
        self.var_warranty=StringVar()
        


        #1st
        img=Image.open(r"croma.png")
        img=img.resize((450,160),Image.ANTIALIAS)
        self.photoimg=ImageTk.PhotoImage(img)
        
        self.btn_1=Button(self.root,command=self.open_img,image=self.photoimg,cursor="hand2")
        self.btn_1.place(x=0,y=0,width=450,height=160)

        #2nd
        img_2=Image.open(r"reliance.png")
        img_2=img_2.resize((450,160),Image.ANTIALIAS)
        self.photoimg_2=ImageTk.PhotoImage(img_2)
        
        self.btn_2=Button(self.root,command=self.open_img2,image=self.photoimg_2,cursor="hand2")
        self.btn_2.place(x=455,y=0,width=450,height=160)

        #3rd
        img_3=Image.open(r"sargam.jpg")
        img_3=img_3.resize((450,160),Image.ANTIALIAS)
        self.photoimg_3=ImageTk.PhotoImage(img_3)
        
        self.btn_3=Button(self.root,command=self.open_img3,image=self.photoimg_3,cursor="hand2")
        self.btn_3.place(x=910,y=0,width=450,height=160)

        #bg image
        img_4=Image.open(r"bg2.jpg")
        img_4=img_4.resize((1530,710),Image.ANTIALIAS)
        self.photoimg_4=ImageTk.PhotoImage(img_4)

        bg_lbl=Label(self.root,image=self.photoimg_4,bd=2,relief=RIDGE)
        bg_lbl.place(x=0,y=160,width=1530,height=710)

        lbl_title=Label(bg_lbl,text="ELECTRONIC SHOP MANAGEMENT SYSTEM",font=("times new roman",37,"bold"),fg="blue",bg="white")
        lbl_title.place(x=0,y=0,width=1400,height=50)

        #manage frame
        Manage_frame=Frame(bg_lbl,bd=2,relief=RIDGE,bg="white")
        Manage_frame.place(x=8,y=55,width=1340,height=475)

        #left frame
        DataLeftFrame=LabelFrame(Manage_frame,bd=4,relief=RIDGE,padx=2,text="Product Information",font=("times new roman",12,"bold"),fg="red",bg="white")
        DataLeftFrame.place(x=2,y=10,width=660,height=450)

        #img
        img_5=Image.open(r"pro.png")
        img_5=img_5.resize((650,100),Image.ANTIALIAS)
        self.photoimg_5=ImageTk.PhotoImage(img_5)

        my_img=Label(DataLeftFrame,image=self.photoimg_5,bd=2,relief=RIDGE)
        my_img.place(x=0,y=2,width=650,height=60)

        #Product information labelframe information
        std_lbl_info_frame=LabelFrame(DataLeftFrame,bd=4,relief=RIDGE,padx=2,text="Product Warehouse",font=("times new roman",12,"bold"),fg="red",bg="white")
        std_lbl_info_frame.place(x=0,y=40,width=650,height=105)

        #labels and combobox
        #department
        lbl_dep=Label(std_lbl_info_frame,text="Store:",font=("arial",12,"bold"),bg="white")
        lbl_dep.grid(row=0,column=0,padx=2,sticky=W)

        combo_dep=ttk.Combobox(std_lbl_info_frame,textvariable=self.var_store,font=("arial",12,"bold"),width=17,state="readonly")
        combo_dep["value"]=("Select Store","Croma","Reliance Digital","Sargam","Vijay Sales")
        combo_dep.current(0)
        combo_dep.grid(row=0,column=1,padx=2,pady=10,sticky=W)  

        #category
        course_std=Label(std_lbl_info_frame,text="Category:",font=("arial",12,"bold"),bg="white")
        course_std.grid(row=0,column=2,padx=2,sticky=W,pady=10)

        com_txtcourse_std=ttk.Combobox(std_lbl_info_frame,textvariable=self.var_category,font=("arial",12,"bold"),width=17,state="readonly")
        com_txtcourse_std["value"]=("Select Category","T.V","Smartphone","A.C","Laptops")
        com_txtcourse_std.current(0)
        com_txtcourse_std.grid(row=0,column=3,padx=2,pady=10,sticky=W)  

        #year
        current_year=Label(std_lbl_info_frame,text="Year:",font=("arial",12,"bold"),bg="white")
        current_year.grid(row=1,column=0,padx=2,sticky=W,pady=10)

        com_txt_current_year=ttk.Combobox(std_lbl_info_frame,textvariable=self.var_year,font=("arial",12,"bold"),width=17,state="readonly")
        com_txt_current_year["value"]=("Select Year","2019","2020","2021","2022")
        com_txt_current_year.current(0)
        com_txt_current_year.grid(row=1,column=1,padx=2,pady=10,sticky=W) 

        #place 
        label_semester=Label(std_lbl_info_frame,text="Place:",font=("arial",12,"bold"),bg="white")
        label_semester.grid(row=1,column=2,padx=2,sticky=W,pady=10)

        comSemenster=ttk.Combobox(std_lbl_info_frame,textvariable=self.var_place,font=("arial",12,"bold"),width=17,state="readonly")
        comSemenster["value"]=("Select Place","Delhi","Gurugram","Ghaziabad","Vaishali")
        comSemenster.current(0)
        comSemenster.grid(row=1,column=3,padx=2,pady=10,sticky=W) 

        #Product detailed information labelframe information
        std_lbl_class_frame=LabelFrame(DataLeftFrame,bd=4,relief=RIDGE,padx=2,text="Product Details",font=("times new roman",12,"bold"),fg="red",bg="white")
        std_lbl_class_frame.place(x=0,y=150,width=650,height=220)

        #label entry
        #id
        lbl_id=Label(std_lbl_class_frame,text="Product ID:",font=("arial",12,"bold"),bg="white")
        lbl_id.grid(row=0,column=0,padx=2,sticky=W,pady=7)

        id_entry=ttk.Entry(std_lbl_class_frame,textvariable=self.var_id,font=("aerial",12,"bold"),width=22)
        id_entry.grid(row=0,column=1,sticky=W,padx=2,pady=7)

        #name
        lbl_name=Label(std_lbl_class_frame,text="Product Name:",font=("arial",12,"bold"),bg="white")
        lbl_name.grid(row=0,column=2,padx=2,sticky=W,pady=7)

        txt_name=ttk.Entry(std_lbl_class_frame,textvariable=self.var_name,font=("aerial",12,"bold"),width=22)
        txt_name.grid(row=0,column=3,sticky=W,padx=2,pady=7)

        #company name
        lbl_div=Label(std_lbl_class_frame,text="Company Name:",font=("arial",12,"bold"),bg="white")
        lbl_div.grid(row=1,column=0,padx=2,sticky=W,pady=7)

        com_txt_div=ttk.Combobox(std_lbl_class_frame,textvariable=self.var_company,state="readonly",font=("aerial",12,"bold"),width=18)
        com_txt_div["value"]=("Select Company","Samsung","Sony","LG","Realme","Redmi")
        com_txt_div.current(0)
        com_txt_div.grid(row=1,column=1,sticky=W,padx=2,pady=7)

        #model no
        lbl_roll=Label(std_lbl_class_frame,text="Model No:",font=("arial",12,"bold"),bg="white")
        lbl_roll.grid(row=1,column=2,padx=2,sticky=W,pady=7)

        txt_roll=ttk.Entry(std_lbl_class_frame,textvariable=self.var_model,font=("aerial",12,"bold"),width=22)
        txt_roll.grid(row=1,column=3,sticky=W,padx=2,pady=7)

        #Rating
        lbl_rate=Label(std_lbl_class_frame,text="Rating:",font=("arial",12,"bold"),bg="white")
        lbl_rate.grid(row=2,column=0,padx=2,sticky=W,pady=7)

        com_txt_rate=ttk.Combobox(std_lbl_class_frame,textvariable=self.var_rating,state="readonly",font=("aerial",12,"bold"),width=18)
        com_txt_rate["value"]=("Select Rating","0","1","2","3","4","5")
        com_txt_rate.current(0)
        com_txt_rate.grid(row=2,column=1,sticky=W,padx=2,pady=7)

        #price
        lbl_dob=Label(std_lbl_class_frame,text="Price:",font=("arial",12,"bold"),bg="white")
        lbl_dob.grid(row=2,column=2,padx=2,sticky=W,pady=7)

        txt_dob=ttk.Entry(std_lbl_class_frame,textvariable=self.var_price,font=("aerial",12,"bold"),width=22)
        txt_dob.grid(row=2,column=3,sticky=W,padx=2,pady=7)
        
        #quantity
        lbl_email=Label(std_lbl_class_frame,text="Quantity:",font=("arial",12,"bold"),bg="white")
        lbl_email.grid(row=3,column=0,padx=2,sticky=W,pady=7)

        txt_email=ttk.Entry(std_lbl_class_frame,textvariable=self.var_quantity,font=("aerial",12,"bold"),width=22)
        txt_email.grid(row=3,column=1,sticky=W,padx=2,pady=7)

        #mrp
        lbl_phone=Label(std_lbl_class_frame,text="M.R.P:",font=("arial",12,"bold"),bg="white")
        lbl_phone.grid(row=3,column=2,padx=2,sticky=W,pady=7)

        txt_phone=ttk.Entry(std_lbl_class_frame,textvariable=self.var_mrp,font=("aerial",12,"bold"),width=22)
        txt_phone.grid(row=3,column=3,sticky=W,padx=2,pady=7)

        #customer care no
        lbl_address=Label(std_lbl_class_frame,text="Customer Care:",font=("arial",12,"bold"),bg="white")
        lbl_address.grid(row=4,column=0,padx=2,sticky=W,pady=7)

        txt_address=ttk.Entry(std_lbl_class_frame,textvariable=self.var_phone,font=("aerial",12,"bold"),width=22)
        txt_address.grid(row=4,column=1,sticky=W,padx=2,pady=7)

        #warranty
        lbl_teacher=Label(std_lbl_class_frame,text="Warranty:",font=("arial",12,"bold"),bg="white")
        lbl_teacher.grid(row=4,column=2,padx=2,sticky=W,pady=7)

        txt_teacher=ttk.Entry(std_lbl_class_frame,textvariable=self.var_warranty    ,font=("aerial",12,"bold"),width=22)
        txt_teacher.grid(row=4,column=3,sticky=W,padx=2,pady=7)

        #button frame
        btn_frame=Frame(DataLeftFrame,bd=2,relief=RIDGE,bg="white")
        btn_frame.place(x=0,y=380,width=650,height=38)
        
        btn_Add=Button(btn_frame,text="Save",command=self.add_data,font=("arial",11,"bold"),width=17,bg="blue",fg="white")
        btn_Add.grid(row=0,column=0,padx=1)

        btn_Update=Button(btn_frame,text="Update",command=self.update_data,font=("arial",11,"bold"),width=17,bg="blue",fg="white")
        btn_Update.grid(row=0,column=1,padx=1)

        btn_Delete=Button(btn_frame,text="Delete",command=self.delete_data,font=("arial",11,"bold"),width=17,bg="blue",fg="white")
        btn_Delete.grid(row=0,column=2,padx=1)

        btn_Reset=Button(btn_frame,text="Reset",command=self.reset_data,font=("arial",11,"bold"),width=17,bg="blue",fg="white")
        btn_Reset.grid(row=0,column=3,padx=1)

        
        #right frame
        DataRightFrame=LabelFrame(Manage_frame,bd=4,relief=RIDGE,padx=2,text="Stock Information",font=("times new roman",12,"bold"),fg="red",bg="white")
        DataRightFrame.place(x=675,y=10,width=660,height=450)        

        #img1
        img_6=Image.open(r"bg3.jpg")
        img_6=img_6.resize((780,200),Image.ANTIALIAS)
        self.photoimg_6=ImageTk.PhotoImage(img_6)

        bg_lbl=Label(DataRightFrame,image=self.photoimg_6,bd=2,relief=RIDGE)
        bg_lbl.place(x=0,y=0,width=650,height=120)

        #right frame
        Search_Frame=LabelFrame(DataRightFrame,bd=4,relief=RIDGE,padx=2,text="Search Stock Information",font=("times new roman",12,"bold"),fg="red",bg="white")
        Search_Frame.place(x=0,y=100,width=650,height=70) 

        search_by=Label(Search_Frame,text="Search By:",font=("arial",12,"bold"),fg="red",bg="white")
        search_by.grid(row=0,column=0,padx=2,sticky=W,pady=7)

        #search
        self.var_com_search=StringVar()
        com_txt_search=ttk.Combobox(Search_Frame,textvariable=self.var_com_search,state="readonly",font=("aerial",11,"bold"),width=18)
        com_txt_search["value"]=("Select OPTION","Product ID","Rating")
        com_txt_search.current(0)
        com_txt_search.grid(row=0,column=1,sticky=W,padx=2)

        self.var_search=StringVar()
        txt_search=ttk.Entry(Search_Frame,textvariable=self.var_search,font=("aerial",12,"bold"),width=22)
        txt_search.grid(row=0,column=2,sticky=W,padx=2)

        btn_search=Button(Search_Frame,command=self.search_data,text="Search",font=("aerial",12,"bold"),width=6,bg="blue",fg="white")
        btn_search.grid(row=0,column=3,sticky=W,padx=5)

        btn_ShowAll=Button(Search_Frame,command=self.fetch_data,text="Show All",font=("aerial",12,"bold"),width=6,bg="blue",fg="white")
        btn_ShowAll.grid(row=0,column=4,sticky=W,padx=5)

        #product table and scrollbar
        table_frame=Frame(DataRightFrame,bd=4,relief=RIDGE)
        table_frame.place(x=0,y=170,width=648,height=255)

        scroll_x=ttk.Scrollbar(table_frame,orient=HORIZONTAL)
        scroll_y=ttk.Scrollbar(table_frame,orient=VERTICAL)
        self.electronic_table=ttk.Treeview(table_frame,column=("store","category","year","place","id","name","company","model","rating","price","quantity","mrp","phone","warranty",),xscrollcommand=scroll_x.set,yscrollcommand=scroll_y.set)

        scroll_x.pack(side=BOTTOM,fill=X)
        scroll_y.pack(side=RIGHT,fill=Y)

        scroll_x.config(command=self.electronic_table.xview)
        scroll_y.config(command=self.electronic_table.yview)

        self.electronic_table.heading("store",text="Store")
        self.electronic_table.heading("category",text="Category")
        self.electronic_table.heading("year",text="Year")
        self.electronic_table.heading("place",text="Place")
        self.electronic_table.heading("id",text="Product ID")
        self.electronic_table.heading("name",text="Product Name")
        self.electronic_table.heading("company",text="Company Name")
        self.electronic_table.heading("model",text="Model No")
        self.electronic_table.heading("rating",text="Rating")
        self.electronic_table.heading("price",text="Price")
        self.electronic_table.heading("quantity",text="Quantity")
        self.electronic_table.heading("mrp",text="M.R.P")
        self.electronic_table.heading("phone",text="Phone")
        self.electronic_table.heading("warranty",text="Warranty")

        self.electronic_table["show"]="headings"

        self.electronic_table.column("store",width=100)
        self.electronic_table.column("category",width=100)
        self.electronic_table.column("year",width=100)
        self.electronic_table.column("place",width=100)
        self.electronic_table.column("id",width=100)
        self.electronic_table.column("name",width=100)
        self.electronic_table.column("company",width=100)
        self.electronic_table.column("model",width=100)
        self.electronic_table.column("rating",width=100)
        self.electronic_table.column("price",width=100)
        self.electronic_table.column("quantity",width=100)
        self.electronic_table.column("mrp",width=100)
        self.electronic_table.column("phone",width=100)
        self.electronic_table.column("warranty",width=100) 


        self.electronic_table.pack(fill=BOTH,expand=1)
        self.electronic_table.bind("<ButtonRelease>",self.get_cursor)
        self.fetch_data()

    def add_data(self):
        if (self.var_store.get()=="" or self.var_id.get()==""):
            messagebox.showerror("Error","All Fields Are Required")
        else:
            try:
                conn=mysql.connector.connect(host="localhost",user="root",password="urvashi22",database="mydata")
                my_cursor=conn.cursor()
                my_cursor.execute("Insert Into Electronic Values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",(
                                                                                                            self.var_store.get(),
                                                                                                            self.var_category.get(),
                                                                                                            self.var_year.get(),
                                                                                                            self.var_place.get(),
                                                                                                            self.var_id.get(),
                                                                                                            self.var_name.get(),
                                                                                                            self.var_company.get(),
                                                                                                            self.var_model.get(),
                                                                                                            self.var_rating.get(),
                                                                                                            self.var_price.get(),
                                                                                                            self.var_quantity.get(),
                                                                                                            self.var_mrp.get(),
                                                                                                            self.var_phone.get(),
                                                                                                            self.var_warranty.get(),


                                                                                                   ))
                conn.commit()
                self.fetch_data()
                conn.close()
                messagebox.showinfo("Success","Product Has Been Added!",parent=self.root)
            except Exception as es:
                messagebox.showerror("Error",f"Due To:{str(es)}",parent=self.root)

    #fetch function 
    def fetch_data(self):
        conn=mysql.connector.connect(host="localhost",user="root",password="urvashi22",database="mydata")
        my_cursor=conn.cursor()
        my_cursor.execute("select * from electronic")
        data=my_cursor.fetchall()
        if len(data)!=0:
            self.electronic_table.delete(*self.electronic_table.get_children())
            for i in data:
                self.electronic_table.insert("",END,values=i)
            conn.commit()
        conn.close()

    #get cursur
    def get_cursor(self,event=""):
        cursor_row=self.electronic_table.focus()
        content=self.electronic_table.item(cursor_row)
        data=content["values"]
        
        self.var_store.set(data[0])
        self.var_category.set(data[1])
        self.var_year.set(data[2])
        self.var_place.set(data[3])
        self.var_id.set(data[4])
        self.var_name.set(data[5])
        self.var_company.set(data[6])
        self.var_model.set(data[7])
        self.var_rating.set(data[8])
        self.var_price.set(data[9])
        self.var_quantity.set(data[10])
        self.var_mrp.set(data[11])
        self.var_phone.set(data[12])
        self.var_warranty.set(data[13])

    def update_data(self):
        if self.var_id.get()=="" or self.var_name.get()=="" or self.var_rating.get()=="":
            messagebox.showerror("Error","All Fields Are Required")
        else:
            #try:
            update=messagebox.askyesno("Update","are you sure to update this product data",parent=self.root)
            if update>0:
                conn=mysql.connector.connect(host="localhost",user="root",password="urvashi22",database="mydata")
                my_cursor=conn.cursor()
                my_cursor.execute("update Electronic set Price={}, Quantity={} where product_id={};".format(self.var_price.get(),self.var_quantity.get(),self.var_id.get()))
            else:
                if not update:
                    return
            conn.commit()
            self.fetch_data()
            conn.close()
            
            messagebox.showinfo("Success","Product successfully updated",parent=self.root)
            #except Exception as es:
             #   messagebox.showerror("Error",f"Due To:{str(es)}",parent=self.root)
                

    #delete
    def delete_data(self):
        if self.var_id.get()=="" or self.var_name.get()=="":
            messagebox.showerror("Error","All Fields Are Required")
        else:
            try:
                Delete=messagebox.askyesno("Delete","Are you sure to delete this product",parent=self.root)
                if Delete>0:
                    conn=mysql.connector.connect(host="localhost",user="root",password="urvashi22",database="mydata")
                    my_cursor=conn.cursor()
                    sql="delete from electronic where Product_id=%s and Product_name=%s"
                    value=(self.var_id.get(),self.var_name.get())
                    my_cursor.execute(sql,value)
                else:
                    if not Delete:
                        return
                conn.commit()
                self.fetch_data()
                conn.close()
                messagebox.showinfo("Delete","Your product has been deleted",parent=self.root)
            except Exception as es:
                messagebox.showerror("Error",f"Due To:{str(es)}",parent=self.root)

        
    #reset
    def reset_data(self):
        self.var_store.set("Select Store")
        self.var_category.set("Select Category")
        self.var_year.set("Select Year")
        self.var_place.set("Select Place")
        self.var_id.set("")
        self.var_name.set("")
        self.var_company.set("Select Company")
        self.var_model.set("")
        self.var_rating.set("")
        self.var_price.set("")
        self.var_quantity.set("")
        self.var_mrp.set("")
        self.var_phone.set("")
        self.var_warranty.set("")
        
    #search data
    def search_data(self):
        if self.var_com_search.get()=="" or self.var_search.get()=="":
            messagebox.showerror("Error","Please select option")
        else:
            try:
                conn=mysql.connector.connect(host="localhost",user="root",password="urvashi22",database="mydata")
                my_cursor=conn.cursor()
                my_cursor.execute("select * from electronic where " +str(self.var_com_search.get()+"=")+str(self.var_search.get()))
                data=my_cursor.fetchall()
                if len(data)!=0:
                    self.electronic_table.delete(*self.electronic_table.get_children())
                    for i in data:
                        self.electronic_table.insert("",END,values=i)
                    conn.commit()
                conn.close()
            except Exception as es:
                messagebox.showerror("Error",f"Due To:{str(es)}",parent=self.root)

     
    #open image
    def open_img(self):
        fln=filedialog.askopenfilename(initialdir=os.getcwd(),title="Open Images",filetypes=(("JPG File","*.jpg"),("PNG File","*.png"),("All Files","*.*")))
        img=Image.open(fln)
        img_browse=img.resize((450,160),Image.ANTIALIAS)
        self.photoimg_browse=ImageTk.PhotoImage(img_browse)
        self.btn_1.config(image=self.photoimg_browse)

    #open image
    def open_img2(self):
        fln=filedialog.askopenfilename(initialdir=os.getcwd(),title="Open Images",filetypes=(("JPG File","*.jpg"),("PNG File","*.png"),("All Files","*.*")))
        img_1=Image.open(fln)
        img_browse_1=img_1.resize((450,160),Image.ANTIALIAS)
        self.photoimg_browse=ImageTk.PhotoImage(img_browse_1)
        self.btn_2.config(image=self.photoimg_browse_1)

    #open image
    def open_img3(self):
        fln=filedialog.askopenfilename(initialdir=os.getcwd(),title="Open Images",filetypes=(("JPG File","*.jpg"),("PNG File","*.png"),("All Files","*.*")))
        img_2=Image.open(fln)
        img_browse_2=img_2.resize((450,160),Image.ANTIALIAS)
        self.photoimg_browse_2=ImageTk.PhotoImage(img_browse_2)
        self.btn_3.config(image=self.photoimg_browse_2)



    
if __name__ == "__main__":
    root=Tk()
    obj=Electronic(root)
    root.mainloop()
