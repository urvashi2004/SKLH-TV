from tkinter import *
from RequestPage import *
from YourContentPage import *

def HomePageChoicesFunc():
    root = Tk()

    root.geometry("1280x720")
    root.title("HOME PAGE")
    root.resizable(False, False)
    root.config(bg = "#5E17EB")

    label_heading = Label(root, text = "SKLH TV", justify = "center",bg='#5E17EB',fg='yellow', font = ("Arial", 40))
    label_heading.place(x=500, y=40, width=300, height=75)

    def ClickExp():
        root.destroy()

    explore_but = Button(root, text = "Explore", font = ("Arial", 25),bg='#F4C24F', command=lambda:ClickExp())
    explore_but.place(x=110, y=200, width=400, height=200)

    def ClickYour():
        root.destroy()
        YourContentPageFunc()

    your_but = Button(root, text = "Your Content", font = ("Arial", 25),bg='#1CB9D3', command=lambda:ClickYour())
    your_but.place(x=800, y=200, width=400, height=200)

    def ClickRecs():
        root.destroy()

    recs_but = Button(root, text = "Reccomendations", font = ("Arial", 25),bg='#DB0142', command=lambda:ClickRecs())
    recs_but.place(x=110, y=450, width=400, height=200)

    def ClickReq():
        root.destroy()
        RequestPageFunc()

    req_but = Button(root, text = "Request To Add", font = ("Arial", 25),bg='#FFA6DD', command=lambda:ClickReq())
    req_but.place(x=800, y=450, width=400, height=200)

    def Click():
        from Choice import ChoiceFunc
        root.destroy()
        ChoiceFunc()

    logout = Button(root, text="LOGOUT", font = ("Arial", 15),bg='#5E17EB',fg='#FE606D', borderwidth=0, command=lambda:Click())
    logout.place(x=5 ,y=5, width=100, height=60)

    root.mainloop()
