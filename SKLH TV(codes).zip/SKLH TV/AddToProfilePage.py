from tkinter import * 

def AddToProfilePageFunc():
    root = Tk()

    root.geometry("1280x720")
    root.title("Add To Your Profile Page")
    root.configure(bg = "#5E17EB")
    root.resizable(False, False)

    type_label = Label(root, text = "Select One", font = ("Arial", 40),bg='#5E17EB',fg='#06C2B9')
    type_label.place(x=450, y=40, width=400, height=75)

    want_but = Button(root, text = "Want To Watch", font = ("Arial", 25),bg='#FFBE2D')
    want_but.place(x=100, y=220, width=500, height=200)

    watch_but = Button(root, text = "Watching", font = ("Arial", 25),bg='#EE8560')
    watch_but.place(x=700, y=220, width=500, height=200)

    done_but = Button(root, text = "Already Watched", font = ("Arial", 25),bg='#018D1a')
    done_but.place(x=400, y=480, width=500, height=200)

    button_back = Button(root, text="BACK", font = ("Arial", 20),bg="#5E17EB",fg='#FE606D', borderwidth=0)
    button_back.place(x=5 ,y=5, width=90, height=60)

    root.mainloop()
