from tkinter import *

def ChoiceFunc(root):

    root.title("Choice Page")

    def ClickReg():
        Destroy()
        from Register import RegisterFunc
        RegisterFunc(root)

    def ClickLog():
        Destroy()
        from Login import LoginFunc
        LoginFunc(root)

    type_label = Label(root, text = "Select An Option To Enter", font = ("Gabriola", 35), bg = '#C7C7FB')
    type_label.place(x = 210, y = 80, width = 840, height = 75)

    register_but = Button(root, text = "Register", font = ("Gabriola", 35), bg = '#CCCCFF', command = lambda:ClickReg())
    register_but.place(x = 210, y = 220, width = 400, height = 400)

    log_but = Button(root, text = "Login", font = ("Gabriola", 35), bg = '#CCCCFF', command = lambda:ClickLog())
    log_but.place(x = 650, y = 220, width = 400, height = 400)

    button_quit = Button(root, text = "Quit", font = ("Gabriola", 30), bg = '#CBCFEF', command = lambda:root.destroy())
    button_quit.place(x = 5 ,y = 5, width = 100, height = 60)

    def Destroy():
        type_label.destroy()
        register_but.destroy()
        log_but.destroy()
        button_quit.destroy()