from tkinter import *
from tkinter import messagebox
import mysql.connector as ms
from HomePageChoices import *


db = ms.connect(host = "localhost", user = "root", passwd = "urvashi22")

if db.is_connected():
    print("Connection Established On ForgotPassPage Page")
else:
    print("Connection Not Connected On ForgotPassPage Page")

cs = db.cursor()
cs.execute("use sklh_tv;")


def ForgotPassFunc(root):
    cs.execute("select * from users;")

    data = cs.fetchall()

    root.title("Forgot Password Page")

    #specifying variable types for entry widget
    username_var = StringVar()
    passwd_var = StringVar()
    conpasswd_var = StringVar()

    def submit():
        username = username_var.get()
        passwd = passwd_var.get()
        conpasswd = conpasswd_var.get()

        username_var.set("")
        passwd_var.set("")
        conpasswd_var.set("")
        
        #specifying conditions to insert data

        con1 = False
        con2 = False

        for i in data:
            if i[0] == username:
                record = i
                print("Username found in database")
                con1 = True
                if passwd == conpasswd:
                    con2 = True
                else:
                    print("Passwords inserted not same")
                break
            else:
                print("Username does not exists")

        if con1 == False:
            Destroy()
            messagebox.showerror("Username Error", "Username not in database")
            from Login import LoginFunc
            LoginFunc(root)

        elif con2 == False:
            Destroy()
            messagebox.showerror("Password Error", "Passwords do not match")
            from Login import LoginFunc
            LoginFunc(root)

        else:

            try:
                cs.execute("update users set Password = '" + passwd + "' where Username = '" + username + "';")
                print("Data insertion successful")
                db.commit()
                print("Data inserted in table is", username.lower(), passwd)
                messagebox.showinfo("Info", "User Password Changed")
                Destroy()
                from HomePageChoices import HomePageChoicesFunc
                HomePageChoicesFunc(root, username)

            except:
                Destroy()
                print("Data insertion failed")
                messagebox.showerror("Error", "Could Not Register User")
                LoginFunc(root)
    

    head_label = Label(root, text = "Login", justify = "center", font = ("Gabriola", 30), bg = '#C7C7FB')
    head_label.place(x = 110, y = 80, width = 1025, height = 75)

    username_label = Label(root, text = "Username : ", font = ("Gabriola", 30), bg = '#CCCCFF')
    username_label.place(x = 110, y = 280, width = 300, height = 75)

    username_entry = Entry(root, textvariable = username_var, font = ("Gabriola", 30), bg = '#E6E6FA', justify = "center")
    username_entry.place(x = 420, y = 280, width = 750, height = 75)

    passwd_label = Label(root, text = "Password : ", font = ("Gabriola", 30), bg = '#CCCCFF')
    passwd_label.place(x = 110, y = 385, width = 300, height = 75)

    passwd_entry = Entry(root, textvariable = passwd_var, font = ("Gabriola", 30), bg = '#E6E6FA', show = "*", justify = "center")
    passwd_entry.place(x = 420, y = 385, width = 750, height = 75)

    conpasswd_label = Label(root, text = "Confirm Password : ", font = ("Gabriola", 30), bg = '#CCCCFF')
    conpasswd_label.place(x = 110, y = 490, width = 300, height = 75)

    conpasswd_entry = Entry(root, textvariable = conpasswd_var, font = ("Gabriola", 30), bg = '#E6E6FA', show = "*", justify = "center")
    conpasswd_entry.place(x = 420, y = 490, width = 750, height = 75)

    sub_button = Button(root, text = "Save Entry", font = ("Gabriola", 30), bg = '#CBCFEF', command = lambda:submit())
    sub_button.place(x = 410, y = 600, width = 457, height = 75)
    
    def Click():
        Destroy()
        from Login import LoginFunc
        LoginFunc(root)

    button_back = Button(root, text = "Back", font = ("Gabriola", 25), bg = '#CBCFEF', command = lambda:Click())
    button_back.place(x = 5 ,y = 5, width = 100, height = 60)

    def Destroy():
        head_label.destroy()
        username_label.destroy()
        username_entry.destroy()
        passwd_label.destroy()
        passwd_entry.destroy()
        conpasswd_label.destroy()
        conpasswd_entry.destroy()
        sub_button.destroy()
        button_back.destroy()