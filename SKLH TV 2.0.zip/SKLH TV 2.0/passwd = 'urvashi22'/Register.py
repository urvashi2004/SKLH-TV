from tkinter import *
from tkinter import messagebox
import mysql.connector as ms
from Choice import *

def RegisterFunc(root):
    root.title("Register Page")

    db = ms.connect(host = "localhost", user = "root", passwd = "urvashi22")

    if db.is_connected():
        print("Connection Established On Register Page")
    else:
        print("Connection Not Connected On Register Page")

    cs = db.cursor()
    cs.execute("use sklh_tv;")

    cs.execute("select * from users;")

    data = cs.fetchall()

    #specifying variable types for entry widget
    fullname_var = StringVar()
    username_var = StringVar()
    passwd_var = StringVar()
    conpasswd_var = StringVar()

    def Submit():
        fullname = fullname_var.get()
        username = username_var.get()
        passwd = passwd_var.get()
        conpasswd = conpasswd_var.get()

        #specifying conditions to insert data

        con1 = False
        con2 = False

        print(data)
        for i in data:
            if i[0] != username:
                con1 = True
                break
            else:
                print("Username already used")
        else:
            con1 = True
                
        if passwd == conpasswd:
            con2 = True
        else:
            print("Passwords inserted not same")
        

        if con1 == False:
            Destroy()
            messagebox.showerror("Username Error", "Username is already used.")
            ChoiceFunc(root)

        elif con2 == False:
            Destroy()
            messagebox.showerror("Password Error", "Passwords inserted are not same!")
            ChoiceFunc(root)

        else:
            try:
                cs.execute("insert into users values ('" + username.lower() + "', '" + fullname.title() + "', '" + passwd + "');")
                print("Data insertion successful")
                cs.execute("create table " + username + "content (ID char(4) not null, Status varchar(25), Rating int);")
                db.commit()
                print("Data inserted in table is", fullname.title(), username.lower(), passwd)
                messagebox.showinfo("Info", "User Registered")
                Destroy()
                from HomePageChoices import HomePageChoicesFunc
                HomePageChoicesFunc(root, username)
            except:
                Destroy()
                print("Data insertion failed")
                messagebox.showerror("Error", "Could Not Register User")
                ChoiceFunc(root)

        fullname_var.set("")
        username_var.set("")
        passwd_var.set("")
        conpasswd_var.set("")

    head_label = Label(root, text = "Register", justify = "center", font = ("Gabriola", 30), bg = '#C7C7FB')
    head_label.place(x = 110, y = 60, width = 1060, height = 75)

    fullname_label = Label(root, text = "Full Name : ", font = ("Gabriola", 30), bg = '#CCCCFF')
    fullname_label.place(x = 110, y = 175, width = 300, height = 75)

    fullname_entry = Entry(root, textvariable = fullname_var, font = ("Gabriola", 30), bg = '#E6E6FA', justify = "center")
    fullname_entry.place(x = 420, y = 175, width = 750, height = 75)

    username_label = Label(root, text = "Username : ", font = ("Gabriola", 30), bg = '#CCCCFF')
    username_label.place(x = 110, y = 280, width = 300, height = 75)

    username_entry = Entry(root, textvariable = username_var, font = ("Gabriola", 30), bg = '#E6E6FA', justify = "center")
    username_entry.place(x = 420, y = 280, width = 750, height = 75)

    passwd_label = Label(root, text = "Password : ", font = ("Gabriola", 30), bg = '#CCCCFF')
    passwd_label.place(x = 110, y = 385, width = 300, height = 75)

    passwd_entry = Entry(root, textvariable = passwd_var, font = ("Gabriola", 30), bg = '#E6E6FA', show = "*", justify = "center")
    passwd_entry.place(x = 420, y = 385, width = 750, height = 75)

    conpasswd_label = Label(root, text = "Confirm Password : ", font = ("Gabriola", 30), bg = '#CCCCFF')
    conpasswd_label.place(x = 110, y = 490, width = 300, height = 75)

    conpasswd_entry = Entry(root, textvariable = conpasswd_var, font = ("Gabriola", 30), bg = '#E6E6FA', show = "*", justify = "center")
    conpasswd_entry.place(x = 420, y = 490, width = 750, height = 75)

    sub_button = Button(root, text = "Submit Entry", font = ("Gabriola", 30), bg = '#CBCFEF', command = lambda:Submit())
    sub_button.place(x = 440, y = 600, width = 457, height = 75)

    def Click():
        Destroy()
        ChoiceFunc(root)

    button_back = Button(root, text = "Back", font = ("Gabriola", 25), bg = '#CBCFEF', command = lambda:Click())
    button_back.place(x = 5 ,y = 5, width = 100, height = 60)

    def Destroy():
        head_label.destroy()
        fullname_label.destroy()
        fullname_entry.destroy()
        username_label.destroy()
        username_entry.destroy()
        passwd_label.destroy()
        passwd_entry.destroy()
        conpasswd_label.destroy()
        conpasswd_entry.destroy()
        sub_button.destroy()
        button_back.destroy()