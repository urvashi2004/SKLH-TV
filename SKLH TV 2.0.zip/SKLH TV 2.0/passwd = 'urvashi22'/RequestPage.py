from tkinter import *
from tkinter import messagebox
import mysql.connector as ms

def RequestPageFunc(root, name):
    root.title("Request Page")
    username = name
    
    db = ms.connect(host = "localhost", user = "root", passwd = "urvashi22")

    if db.is_connected():
        print("Connection Established On Request Page")
    else:
        print("Connection Not Connected On Request Page")

    cs = db.cursor()
    cs.execute("use sklh_tv;")

    title_var = StringVar()
    year_var = StringVar()
    type1_var = StringVar()

    def Submit():
        title = title_var.get()
        year = year_var.get()
        type1 = type1_var.get()

        messagebox.showinfo("Request Sent", title.title() + " made in " + year + " is requested successfully. We will soon add it into our database.")

        cs.execute("insert into request values ('" + title.title() + "', '" + year + "', '" + type1 + "');")
        db.commit()

        title_var.set("")
        year_var.set("")
        type1_var.set("")

        Destroy()
        from HomePageChoices import HomePageChoicesFunc
        HomePageChoicesFunc(root, username)

    head_label = Label(root, text = "Request To Add", justify = "center", font = ("Gabriola", 30), bg = '#C7C7FB')
    head_label.place(x = 135, y = 80, width = 1015, height = 75)

    title_label = Label(root, text = "Title : ", font = ("Gabriola", 30), bg = '#CCCCFF')
    title_label.place(x = 135, y = 200, width = 200, height = 75)

    title_entry = Entry(root, textvariable = title_var, font = ("Gabriola", 30), bg = '#E6E6FA', justify = "center")
    title_entry.place(x = 400, y = 200, width = 750, height = 75)

    year_label = Label(root, text = "Year : ", font = ("Gabriola", 30), bg = '#CCCCFF')
    year_label.place(x = 135, y = 340, width = 200, height = 75)

    year_entry = Entry(root, textvariable = year_var, font = ("Gabriola", 30), bg = '#E6E6FA', justify = "center")
    year_entry.place(x = 400, y = 340, width = 750, height = 75)

    type_label = Label(root, text = "Type : ", font = ("Gabriola", 30), bg = '#CCCCFF')
    type_label.place(x = 135, y = 480, width = 200, height = 75)

    type_menu = OptionMenu(root, type1_var, "Movie", "Web Series")
    type_menu.place(x = 400, y = 480, width = 750, height = 75)

    sub_button = Button(root, text = "Submit Entry", font = ("Gabriola", 30), bg = '#CBCFEF', command = lambda:Submit())
    sub_button.place(x = 460, y = 600, width = 457, height = 75)

    def Click():
        Destroy()
        from HomePageChoices import HomePageChoicesFunc
        HomePageChoicesFunc(root, username)

    button_back = Button(root, text = "Back", font = ("Gabriola", 25), bg = '#CBCFEF', command = lambda:Click())
    button_back.place(x = 5 ,y = 5, width = 100, height = 60)
    
    def Destroy():
        head_label.destroy()
        title_label.destroy()
        title_entry.destroy()
        year_label.destroy()
        year_entry.destroy()
        type_label.destroy()
        type_menu.destroy()
        sub_button.destroy()
        button_back.destroy()