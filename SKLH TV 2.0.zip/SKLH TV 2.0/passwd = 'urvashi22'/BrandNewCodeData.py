import mysql.connector as ms

#connecting python with mysql
db = ms.connect(host = "localhost", user = "root", passwd = "urvashi22")

if db.is_connected():
    print("Connection Established On Data Page")
else:
    print("Connection Not Connected On Data Page")

cs = db.cursor()

#creating database for project
cs.execute("drop database if exists sklh_tv;")
cs.execute("create database sklh_tv;")
cs.execute("use sklh_tv;")

#creating tables and inserting pre-defined values in it
cs.execute("create table users(Username varchar(20) primary key not null, Name varchar(40) not null, Password varchar(40) not null);")
cs.execute("insert into users values ('admin', 'Admin', 'passwd');")

cs.execute("create table content(ID char(4) primary key not null, Title varchar(40) not null, Type varchar(10) not null, Year int not null, Country varchar(40), Genre varchar(40), Rating int, Summary varchar(2000));")
cs.execute("insert into content values ('101M', 'Your Name', 'Movie', 2016, 'Japan', 'Fantasy', 9.9, 'Two teenagers share a profound, magical connection upon discovering they are swapping bodies. Things manage to become even more complicated when the boy and girl decide to meet in person.');")
cs.execute("insert into content values ('102S', 'Blood And Water', 'TV Show', 2021, 'South Africa', 'Drama', 9.0, 'After crossing paths at a party, a Cape Town teen sets out to prove whether a private-school swimming star is her sister who was abducted at birth.');")
cs.execute("insert into content values ('103M', 'Intrusion', 'Movie', 2021, 'United States', 'Thriller', 8.5, 'When a husband and wife move to a small town, a home invasion leaves the wife traumatized and suspicious that those around her might not be who they seem.');")
cs.execute("insert into content values ('104M', 'King of Boys', 'Movie', 2018, 'Nigeria', 'Thriller', 6.7, 'Her insatiable appetite for power drives Eniola, a businesswoman and philanthropist, into politics. As she is drawn into a struggle for power her criminal baggage will prove a heavy burden.');")
cs.execute("insert into content values ('105S', 'Castle', 'TV Show', 2009, 'United States', 'Thriller', 8.0, 'After a serial killer imitates the plots of his novels, successful mystery novelist Richard Rick Castle receives permission from the Mayor of New York City to tag along with an NYPD homicide investigation team for research purposes.');")
cs.execute("insert into content values ('106S', 'Bangkok Breaking', 'TV Show', 2021, 'Thailand', 'Drama', 6.4, 'Struggling to earn a living in Bangkok, a man joins an emergency rescue service and realizes he must unravel a citywide conspiracy.');")
cs.execute("insert into content values ('107S', 'Jaguar', 'TV Show', 2021, 'Spain', 'Thriller', 4.0, 'In the 1960s, a Holocaust survivor joins a group of self-trained spies who seek justice against Nazis fleeing to Spain to hide after WWII.');")
cs.execute("insert into content values ('108S', 'Dharmashetra', 'TV Show', 2002, 'India', 'Fantasy', 3.2, 'After the ancient Great War, the god Chitragupta oversees a trial to determine who were the true heroes and villains.');")
cs.execute("insert into content values ('109S', 'Hotel Del Luna', 'TV Show', 2019, 'South Korea', 'Comedy', 9.1, 'When he is invited to manage a hotel for dead souls, an elite hotelier gets to know the ancient owner and her strange world.');")
cs.execute("insert into content values ('110M', 'Cold Mountain', 'Movie', 2003, 'United States', 'Drama', 4.5, 'This drama follows a wounded Civil War soldier making the long journey home, while his faraway love fights for survival on her farm.');")
cs.execute("insert into content values ('111M', 'Shikara', 'Movie', 2020, 'India', 'Romance', 3.2, 'Shiv and Shanti, a young couple, chronicle their love story amid the exodus of Kashmiri Hindus from Kashmir; forced to leave their homes and live as refugees in their own country, the couple, among thousand others, struggle to keep their hopes alive.');")
cs.execute("insert into content values ('112S', 'Kurokos Basketball', 'TV Show', 2015, 'Japan', 'Fantasy', 8.1, 'Five middle school basketball stars went to separate high schools, and now Tetsuya Kuroko and Seirin High are making their play for glory.');")
cs.execute("insert into content values ('113M', 'Level Sixteen', 'Movie', 2018, 'Canada', 'Thriller', 6.4, 'In a bleak academy that teaches girls the virtues of passivity, two students uncover the ghastly purpose behind their training and resolve to escape.');")
cs.execute("insert into content values ('114M', 'Krishna Cottage', 'Movie', 2004, 'India', 'Thriller', 3.1, 'True love is put to the test when another woman comes between a pair of star-crossed young lovers in this thriller.');")
cs.execute("insert into content values ('115S', 'Rebellion', 'TV Show', 2016, 'Ireland', 'Fantasy', 6.4, 'As World War I rages, three women and their families in Dublin choose sides in the violent Easter Rising revolt against British rule.');")
cs.execute("insert into content values ('116M', 'La Diosa Del Asfalto', 'Movie', 2020, 'Mexico', 'Drama', 6.1, 'A woman from a tough neighbourhood outside Mexico City comes home a rock star, inadvertently provoking a confrontation with the ghosts of her past.');")
cs.execute("insert into content values ('117S', 'The Crowned Clown', 'TV Show', 2019, 'South Korea', 'Romance', 6.2, 'Standing in for an unhinged Joseon king, a look-alike clown plays the part but increasingly becomes devoted to protecting the throne and the people.');")
cs.execute("insert into content values ('118S', 'Squid Game', 'TV Show', 2021, 'South Korea', 'Thriller', 9.7, 'Hundreds of cash-strapped players accept a strange invitation to compete in games. Inside, a tempting prize awaits with deadly high stakes.');")
cs.execute("insert into content values ('119M', 'Flower Girl', 'Movie', 2013, 'Nigeria', 'Romance', 7.9, 'When a young florist who has long dreamed of her wedding day gets dumped by her boyfriend, she sets out to win him back with help from a handsome actor.');")
cs.execute("insert into content values ('120S', 'Dogs', 'TV Show', 2021, 'United States', 'Fantasy', 9.4, 'These six intimate stories explore the abiding emotional bonds that form between dogs and their caregivers, no matter the circumstances.');")
cs.execute("insert into content values ('121S', 'Cat People', 'TV Show', 2021, 'United States', 'Fantasy', 8.4, 'Cat people come in all shapes and sizes, but they share a love for their enchanting, unique feline friends. This docuseries reveals their tales.');")
cs.execute("insert into content values ('122S', 'Cuckoo', 'TV Show', 2019, 'United Kingdom', 'Comedy', 2.1, 'Rachel shocks her proper British parents when she marries an American hippie, but it is just the first in a series of surprises for the family.');")
cs.execute("insert into content values ('123S', 'Girl From Nowhere', 'TV Show', 2021, 'Thailand', 'Thriller', 7.9, 'A mysterious, clever girl named Nanno transfers to different schools, exposing the lies and misdeeds of the students and faculty at every turn.');")
cs.execute("insert into content values ('124S', 'Shtisel', 'TV Show', 2021, 'Israel', 'Drama', 2.9, 'A Haredi family living in an ultra-Orthodox neighbourhood of Jerusalem reckons with love, loss and the doldrums of daily life.');")
cs.execute("insert into content values ('125S', 'Undercover', 'TV Show', 2020, 'Belgium', 'Drama', 6.8, 'Undercover agents infiltrate a drug kingpin operation by posing as a couple at the campground where he spends his weekends. Inspired by real events.');")
cs.execute("insert into content values ('126M', 'Ujala', 'Movie',1959, 'India', 'Action', 2.9, 'An honest man dreams of a better life for his family, but a childhood friend leads him into a world of Thriller that keeps happiness just out of reach.');")
cs.execute("insert into content values ('127S', 'Mortel', 'TV Show', 2019, 'France', 'Drama', 3.4, 'After making a deal with a supernatural figure, two high schoolers emerge with extraordinary powers and join forces to solve a murder.');")
cs.execute("insert into content values ('128M', 'Sword Of Trust', 'Movie', 2019, 'United States', 'Comedy', 6.9, 'An offbeat foursome takes a wild journey through the Southern belt of denial to sell a relic purporting to prove the South won the Civil War.');")
cs.execute("insert into content values ('129M', 'Wonder Boy', 'Movie', 2019, 'France', 'Fantasy', 7.9, 'This revealing documentary follows Balmain creative director Olivier Rousteing as he brings his bold designs to life and goes in search of his origins.');")
cs.execute("insert into content values ('130M', 'Life Of Crime', 'Movie', 2013, 'United States', 'Thriller', 9.7, 'After two small-time crooks kidnap and ransom wife of a rich businessman, they discover a flaw in their plan: Her cheating husband does not want her back.');")
cs.execute("insert into content values ('131S', 'Locombianos', 'TV Show', 2021, 'Colombia', 'Comedy', 6.9, 'Four of funniest and bawdiest comedians perform before a post-quarantine audience hungry for their stories.');")
cs.execute("insert into content values ('132M', 'Sweet And Sour', 'Movie', 2021, 'South Korea', 'Romance', 6.1, 'Faced with real-world opportunities and challenges, a couple endures the highs and lows of trying to make a long-distance relationship survive.');")
cs.execute("insert into content values ('133M', 'Carnaval', 'Movie', 2021, 'Brazil', 'Comedy', 5.8, 'After a breakup, an influencer takes her friends on a free trip to Bahia vibrant Carnival, where she learns life is not just about social media likes.');")
cs.execute("insert into content values ('134M', 'The Wedding Guest', 'Movie', 2018, 'United Kingdom', 'Thriller', 3.4, 'Hired to extract a bride-to-be before her arranged wedding in Pakistan, a hired gun goes on the run with his hostage when his plan unravels.');")
cs.execute("insert into content values ('135M', 'Collateral Beauty', 'Movie', 2016, 'United States', 'Romance', 9.3, 'An advertising executive wrestling with grief finds meaning by writing letters to unconventional recipients as caring colleagues plot a ruse.');")
cs.execute("insert into content values ('136S', 'Magic School Bus', 'TV Show',1997, 'Canada', 'Fantasy', 5.9, 'Join Ms. Frizzle as the Magic School Bus travels to outer space, under the sea, through an anthill and even inside the human body');")
cs.execute("insert into content values ('137M', 'Cinema Bandi', 'Movie', 2021, 'India', 'Comedy', 3.1, 'The life of a struggling rickshaw driver takes a rollicking turn when he comes upon an expensive camera and decides to make a film with his fellow villagers.');")
cs.execute("insert into content values ('138M', 'Table Manners', 'Movie', 2018, 'South Africa', 'Comedy', 8.8, 'When picture-perfect life of a housewife comes crashing down, she finds solace and hope through cooking, family and love.');")
cs.execute("insert into content values ('139M', 'Monster', 'Movie', 2021, 'United States', 'Thriller', 7.5, 'A talented teen implicated in a robbery-turned-murder fight for his innocence and integrity against a criminal justice system that has already judged him.');")
cs.execute("insert into content values ('140M', 'Milestone', 'Movie', 2020, 'India', 'Drama', 9.5, 'Recently marking 500,000 kilometres on the road, a newly bereaved trucker faces the threat of losing the job that has come to define him to a new intern.');")

cs.execute("create table admincontent (ID char(4), Status varchar(25), Rating int);")
cs.execute("insert into admincontent values ('101M', 'Watched', 9.0);")
cs.execute("insert into admincontent values ('102S', 'Want To Watch', 5.0);")
cs.execute("insert into admincontent values ('118S', 'Watched', 6.5);")
cs.execute("insert into admincontent values ('136S', 'Watching', 8.0);")

cs.execute("create table request(Title varchar(40) not null, Year int not null, Type varchar(10) not null);")

#pushing data into database
db.commit()