from tkinter import *
from  tkinter import ttk
from tkinter.font import Font
from functools import partial
import mysql.connector as ms
from tkinter import messagebox

def RecommenFunc(root, name):
    root.title("Recommendations Page")
    username = name

    db = ms.connect(host = "localhost", user = "root", passwd = "comp")

    if db.is_connected():
        print("Connection Established On Recommend Page")
    else:
        print("Connection Not Connected On Recommend Page")

    cs = db.cursor()
    cs.execute("use sklh_tv;")

    type_label = Label(root, text = "Recommending Top 7 Titles", font = ("Gabriola", 30), bg = '#C7C7FB')
    type_label.place(x = 125, y = 40, width = 1025, height = 75)

    frame = Frame(root)
    frame.pack()
    frame.place(x = 125, y = 150, width = 1025, height = 523)

    #to style the treeview table
    style = ttk.Style()
    style.theme_use("clam")

    style.configure("Treeview",
        foreground = 'black',
        rowheight = 70)

    style.map('Treeview',
        background = [('selected', '#5E17EB')])

    table1 = ttk.Treeview(frame, height = 7, selectmode = 'browse')
    table1.place(x = 125, y = 150, width = 1060, height = 500)
    table1.pack()

    #defining our columns
    table1['columns'] = ('col_id', 'col_name', 'col_type', 'col_year', 'col_region', 'col_genre', 'col_rating', 'col_summary')

    #formatting our columns
    table1.column("#0", width = 0, stretch = False)
    table1.column("col_id", anchor = CENTER, width = 50)
    table1.column("col_name", anchor = CENTER, width = 110)
    table1.column("col_type", anchor = CENTER, width = 70)
    table1.column("col_year", anchor = CENTER, width = 50)
    table1.column("col_region", anchor = CENTER, width = 100)
    table1.column("col_genre", anchor = CENTER, width = 100)
    table1.column("col_rating", anchor = CENTER, width = 80)
    table1.column("col_summary", anchor = CENTER, width = 460)

    #creating Headings 
    table1.heading("#0", text = "", anchor = CENTER)
    table1.heading("col_id", text = "ID", anchor = CENTER)
    table1.heading("col_name", text = "NAME", anchor = CENTER)
    table1.heading("col_type", text = "TYPE", anchor = CENTER)
    table1.heading("col_year", text = "YEAR", anchor = CENTER)
    table1.heading("col_region", text = "REGION", anchor = CENTER)
    table1.heading("col_genre", text = "GENRE", anchor = CENTER)
    table1.heading("col_rating", text = "RATING", anchor = CENTER)
    table1.heading("col_summary", text = "SUMMARY", anchor = CENTER)

    def Click():
        Destroy()
        from HomePageChoices import HomePageChoicesFunc
        HomePageChoicesFunc(root, username)

    button_back = Button(root, text = "Back", font = ("Gabriola", 25), bg = '#CBCFEF', command = lambda:Click())
    button_back.place(x = 5, y = 5, width = 100, height = 60)

    def Destroy():
        type_label.destroy()
        frame.destroy()
        button_back.destroy()

    #adding data
    cs.execute("select distinct ID, Title, Type, Year, Country, Genre, Rating, Summary from content where ID not in (select ID from " + username + "content) and Genre in (select Genre from " + username + "content) order by rating desc;")

    data = cs.fetchall()

    if data == []:
        messagebox.showerror("Error", "Need To Have Data In Profile To Recommend Titles")
        Destroy()
        from HomePageChoices import HomePageChoicesFunc
        HomePageChoicesFunc(root, username)

    else:
        global k
        k = 0
        for i in range(1,8):
            if k % 2== 0:
                dat = data[i]
                table1.insert(parent = '', index = 'end', iid = i, text = '', values = dat, tag =  ('odd',))
            else:
                dat = data[i]
                table1.insert(parent = '', index = 'end', iid = i, text = '', values = dat, tag =  ('even',))
            k += 1

        table1.tag_configure('odd', background = '#CCCCFF')
        table1.tag_configure('even', background = '#E6E6FA')
        table1.pack()

        def Motion_handler(tree, event):
            f = Font(font = 'TkDefaultFont')
            #helper function that will wrap a given value based on column width
            def Adjust_newlines(val, width, pad = 10):
                if not isinstance(val, str):
                    return val
                else:
                    words = val.split()
                    lines = [[],]
                    for word in words:
                        line = lines[-1] + [word,]
                        if f.measure(' '.join(line)) < (width - pad):
                            lines[-1].append(word)
                        else:
                            lines[-1] = ' '.join(lines[-1])
                            lines.append([word,])

                    if isinstance(lines[-1], list):
                        lines[-1] = ' '.join(lines[-1])

                    return '\n'.join(lines)

            if (event is None) or (tree.identify_region(event.x, event.y) == "separator"):
            
                col_widths = [tree.column(cid)['width'] for cid in tree['columns']]

                for iid in tree.get_children():
                    new_vals = []
                    for (v,w) in zip(tree.item(iid)['values'], col_widths):
                        new_vals.append(Adjust_newlines(v, w))
                    tree.item(iid, values = new_vals)

        table1.bind('<B1-Motion>', partial(Motion_handler, table1))
        Motion_handler(table1, None)   #performing initial wrapping
        table1.pack()